# Database

## Prerequisites

* Docker

## Getting started

Run `setup.sh` to set up a database with mock data for a simple forum app.
