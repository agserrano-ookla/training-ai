docker stop practical-ai-db
docker rm practical-ai-db
